# FreeFlexVPN AI 인계 패키지

1. `manifest.tsv`와 `SHA256SUMS`를 먼저 확인합니다.
2. 이 패키지는 Git 기준 HEAD `9850f17f530f9f990dea080759c9dc26ed7a1408`와 그 위의 미저장 변경을 함께 담습니다.
3. 대화 기억 대신 `30_HANDOFF`와 `20_GIT`을 정본으로 사용합니다.
4. 기존 `ffvpn` 프로필은 삭제·덮어쓰기 금지입니다. 새 검증 프로필의 과거 성공과 기존 프로필의 최신 실패를 구분합니다.
5. 전체 검사 명령: `python -X utf8 70_TOOLS/run_all_tests.py --jobs 4 --timeout 120`
