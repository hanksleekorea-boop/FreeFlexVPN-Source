# 재현 환경

- Windows PowerShell, Python 및 Playwright Chromium이 현재 검사 환경입니다.
- 의존성: `python -m pip install -r requirements-dev.txt`
- 브라우저: `python -m playwright install chromium`
- 전체 검사: `python -X utf8 70_TOOLS/run_all_tests.py --jobs 4 --timeout 120`
- 빌드: `python -X utf8 20_SRC/build_web_assets.py`
- 공개는 기존 승인 채널만 사용하며, 새 공개 경로를 만들지 않습니다.
