# 외부 접근 상태

- Git 원격: https://github.com/hanksleekorea-boop/FreeFlexVPN-Source.git
- 인계 갈래: handoff/v6-2-20260807
- 기준 HEAD: 9850f17f530f9f990dea080759c9dc26ed7a1408
- 공개 서비스: https://storage.googleapis.com/freeflexvpn-live-20260810-a31d7f/app.html
- 현재 작업 폴더에는 다른 작업자의 미저장 변경이 있어, 저장·push·Release는 별도 범위 확인 전 수행하지 않습니다.
- 인증 열쇠·계정·개인 설정·실제 IP는 이 패키지에 넣지 않았습니다.
